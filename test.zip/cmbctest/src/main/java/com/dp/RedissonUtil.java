package com.dp;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.redisson.Redisson;
import org.redisson.api.RMap;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.StringCodec;
import org.redisson.config.Config;

public class RedissonUtil {

  private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
  private static final Config config =
      new Config().setCodec(StringCodec.INSTANCE).setLockWatchdogTimeout(20000L);

  static {
    config
        .useSingleServer()
        .setClientName("clientName")
        .setAddress("redis://testpub:6379")
        .setDatabase(4)
        .setPassword("Datapipeline123")
        .setTimeout(1000 * 60)
        .setSslEnableEndpointIdentification(false);
  }

  private static RedissonClient redissonClient = Redisson.create(config);

  public static Map<String, Map<String, String>> getDeptInfo(String key) {
    final RMap<String, String> depts = redissonClient.getMap(key);
    final Map<String, Map<String, String>> resultMap = new HashMap<String, Map<String, String>>();

    try {
      for (String eachKey : depts.keySet()) {
        Map<String, String> eachDept = new HashMap<String, String>();
        final JsonNode deptJson = OBJECT_MAPPER.readTree(depts.get(eachKey));
        eachDept.put("dept_name", deptJson.get("dept_name").asText());
        eachDept.put("dept_code", deptJson.get("dept_code").asText());
        resultMap.put(eachKey, eachDept);
      }
    } catch (IOException e) {
      throw new RuntimeException("parsing json error!", e);
    }

    return resultMap;
  }

  /**
   * 关闭连接
   */
  public static void shoudown() {
    if (null != redissonClient) {
      redissonClient.shutdown();
    }
  }

  public static void main(String[] args) {
    final Map<String, Map<String, String>> depts = RedissonUtil.getDeptInfo("dept-info");
    System.out.println(depts);
    RedissonUtil.shoudown();
  }
}
