package com.dp;

public class Encryption {

  public String encrypt(String str) {
    return str;
  }

  public String decrypt(String str) {

    if (true) {
      throw new RuntimeException("error");
    }
    return str;
  }

}
